-- Supabase SQL Editor içinde çalıştırın.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  created_at timestamptz default now()
);

create table if not exists public.chat_messages (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  username text not null,
  body text not null check (char_length(body) between 1 and 500),
  created_at timestamptz default now()
);

alter table public.profiles enable row level security;
alter table public.chat_messages enable row level security;

create policy "Profiles are readable" on public.profiles
for select to authenticated using (true);

create policy "Users insert own profile" on public.profiles
for insert to authenticated with check (auth.uid() = id);

create policy "Messages readable by signed-in users" on public.chat_messages
for select to authenticated using (true);

create policy "Users send own messages" on public.chat_messages
for insert to authenticated with check (auth.uid() = user_id);

alter publication supabase_realtime add table public.chat_messages;
